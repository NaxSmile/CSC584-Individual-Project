/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author USER
 */
@WebServlet(name = "ProfileController", urlPatterns = {"/ProfileController"})
public class ProfileController extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String fullname = request.getParameter("fullname");
        String studentid = request.getParameter("studentid");
        String program = request.getParameter("program");
        String email = request.getParameter("email");
        String hobbies = request.getParameter("hobbies");
        String bio = request.getParameter("bio");

        // Validation
        if(fullname.isEmpty() || studentid.isEmpty() ||
           program.isEmpty() || email.isEmpty() ||
           hobbies.isEmpty() || bio.isEmpty()){

            response.getWriter().println("All fields are required!");
            return;
        }

        // Email validation
        if(!email.contains("@") || !email.contains(".")){

            response.getWriter().println("Invalid Email Format!");
            return;
        }

        // request.setAttribute()
        request.setAttribute("fullname", fullname);
        request.setAttribute("studentid", studentid);
        request.setAttribute("program", program);
        request.setAttribute("email", email);
        request.setAttribute("hobbies", hobbies);
        request.setAttribute("bio", bio);

        // request.getRequestDispatcher()
        request.getRequestDispatcher("display.jsp")
               .forward(request, response);
    }
}