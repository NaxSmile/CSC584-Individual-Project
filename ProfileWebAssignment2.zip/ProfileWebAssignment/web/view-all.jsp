<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>All Profiles</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            padding: 20px;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(15px);
            border-radius: 25px;
            padding: 30px;
            border: 1px solid rgba(255, 255, 255, 0.15);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        }

        h1 {
            color: white;
            text-align: center;
            margin-bottom: 30px;
            font-size: 32px;
            letter-spacing: 1px;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .add-btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 12px;
            background: linear-gradient(135deg, #00f5ff, #8f00ff);
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .add-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(0, 245, 255, 0.4);
        }

        .search-box input {
            padding: 10px 15px;
            border-radius: 12px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            width: 250px;
            font-size: 14px;
            outline: none;
            transition: 0.3s;
        }

        .search-box input:focus {
            background: rgba(255, 255, 255, 0.2);
        }

        .search-box input::placeholder {
            color: #aaa;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            color: white;
        }

        th {
            background: rgba(255, 255, 255, 0.1);
            padding: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 13px;
            text-align: center;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            vertical-align: middle;
        }

        tr:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .profile-pic {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #00f5ff;
        }

        .btn-view {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 8px;
            text-decoration: none;
            background: linear-gradient(135deg, #00f5ff, #8f00ff);
            color: white;
            font-weight: bold;
            font-size: 13px;
            transition: 0.3s;
        }

        .btn-view:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px rgba(0, 245, 255, 0.4);
        }

        .empty {
            color: #ccc;
            text-align: center;
            padding: 30px;
            font-size: 18px;
        }

        @media (max-width: 768px) {
            .top-bar {
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
            }
            .search-box input {
                width: 100%;
            }
            table {
                font-size: 12px;
            }
            th, td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📋 All Profiles</h1>

        <div class="top-bar">
            <a href="index.html" class="add-btn">➕ Add New Profile</a>
            <!-- LIVE SEARCH: unique feature -->
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="🔍 Search by Name or Program..." onkeyup="filterTable()">
            </div>
        </div>

        <table id="profileTable">
            <thead>
                <tr>
                    <th>Profile Pic</th>
                    <th>Full Name</th>
                    <th>Student ID</th>
                    <th>Program</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${not empty profileList}">
                        <c:forEach var="p" items="${profileList}">
                            <tr>
                                <td>
                                    <c:choose>
                                        <c:when test="${not empty p.profilePic}">
                                            <img src="${pageContext.request.contextPath}/${p.profilePic}" class="profile-pic" alt="Profile">
                                        </c:when>
                                        <c:otherwise>
                                            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" class="profile-pic" alt="Default">
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${p.fullname}</td>
                                <td>${p.studentid}</td>
                                <td>${p.program}</td>
                                <td>${p.email}</td>
                                <td>
                                    <a href="ProfileController?action=view&id=${p.id}" class="btn-view">View</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <tr><td colspan="6" class="empty">No profiles found. Create your first profile!</td></tr>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>

    <!-- LIVE SEARCH JavaScript -->
    <script>
        function filterTable() {
            var input = document.getElementById("searchInput");
            var filter = input.value.toUpperCase();
            var table = document.getElementById("profileTable");
            var rows = table.getElementsByTagName("tr");

            for (var i = 1; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName("td");
                if (cells.length < 2) continue;
                var nameText = cells[1].textContent || cells[1].innerText;
                var programText = cells[3].textContent || cells[3].innerText;
                if (nameText.toUpperCase().indexOf(filter) > -1 || programText.toUpperCase().indexOf(filter) > -1) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        }
    </script>
</body>
</html>