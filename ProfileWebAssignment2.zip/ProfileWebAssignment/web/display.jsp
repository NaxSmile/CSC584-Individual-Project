<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Profile Card</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins', sans-serif;
        }

        body{
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;

            background:
            linear-gradient(135deg,#141e30,#243b55);
        }

        .card{

            width:380px;

            background:rgba(255,255,255,0.08);

            backdrop-filter:blur(14px);

            border-radius:25px;

            padding:35px;

            text-align:center;

            border:1px solid rgba(255,255,255,0.1);

            box-shadow:
            0 8px 32px rgba(0,0,0,0.4);

            transition:0.4s;
        }

        .card:hover{

            transform:translateY(-5px);

            box-shadow:
            0 15px 40px rgba(0,0,0,0.5);
        }

        .profile-img{

            width:120px;
            height:120px;

            border-radius:50%;

            border:4px solid #00f5ff;

            padding:5px;

            margin-bottom:18px;

            box-shadow:
            0 0 20px rgba(0,245,255,0.6);
        }

        h2{
            color:white;
            font-size:28px;
            margin-bottom:5px;
        }

        .program{
            color:#00f5ff;
            margin-bottom:25px;
            font-size:15px;
        }

        .info{

            background:rgba(255,255,255,0.05);

            border-radius:15px;

            padding:14px;

            margin-bottom:15px;

            text-align:left;
        }

        .label{

            color:#00f5ff;

            font-size:12px;

            text-transform:uppercase;

            letter-spacing:1px;

            margin-bottom:5px;
        }

        .value{
            color:white;
            font-size:15px;
            word-wrap:break-word;
        }

        .bio{
            line-height:1.6;
        }

        .btn{

            display:inline-block;

            margin-top:15px;

            padding:12px 22px;

            border-radius:12px;

            text-decoration:none;

            background:
            linear-gradient(135deg,#00f5ff,#8f00ff);

            color:white;

            font-weight:bold;

            transition:0.3s;
        }

        .btn:hover{

            transform:scale(1.05);

            box-shadow:
            0 0 20px rgba(0,245,255,0.5);
        }

    </style>

</head>

<body>

<div class="card">

    <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
         class="profile-img">

    <h2>
        <%= request.getAttribute("fullname") %>
    </h2>

    <div class="program">
        <%= request.getAttribute("program") %>
    </div>

    <div class="info">

        <div class="label">
            Student ID
        </div>

        <div class="value">
            <%= request.getAttribute("studentid") %>
        </div>

    </div>

    <div class="info">

        <div class="label">
            Email
        </div>

        <div class="value">
            <%= request.getAttribute("email") %>
        </div>

    </div>

    <div class="info">

        <div class="label">
            Hobbies
        </div>

        <div class="value">
            <%= request.getAttribute("hobbies") %>
        </div>

    </div>

    <div class="info bio">

        <div class="label">
            Professional Bio
        </div>

        <div class="value">
            <%= request.getAttribute("bio") %>
        </div>

    </div>

    <a href="index.html" class="btn">
        Back
    </a>

</div>

</body>
</html>