<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Profile Details</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #141e30, #243b55);
            padding: 20px;
        }

        .card {
            width: 420px;
            max-width: 100%;
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(14px);
            border-radius: 25px;
            padding: 35px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            transition: 0.4s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5);
        }

        .profile-img {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #00f5ff;
            padding: 5px;
            margin-bottom: 18px;
            box-shadow: 0 0 20px rgba(0, 245, 255, 0.6);
        }

        .success-msg {
            color: #00ff88;
            font-size: 14px;
            margin-bottom: 15px;
            background: rgba(0, 255, 136, 0.1);
            padding: 10px;
            border-radius: 10px;
            border: 1px solid rgba(0, 255, 136, 0.3);
        }

        h2 {
            color: white;
            font-size: 28px;
            margin-bottom: 5px;
        }

        .program {
            color: #00f5ff;
            margin-bottom: 25px;
            font-size: 16px;
            font-weight: 500;
        }

        .info {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 14px;
            margin-bottom: 15px;
            text-align: left;
        }

        .label {
            color: #00f5ff;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .value {
            color: white;
            font-size: 15px;
            word-wrap: break-word;
        }

        .bio-text {
            line-height: 1.6;
        }

        .btn {
            display: inline-block;
            margin-top: 15px;
            padding: 12px 24px;
            border-radius: 12px;
            text-decoration: none;
            background: linear-gradient(135deg, #00f5ff, #8f00ff);
            color: white;
            font-weight: bold;
            transition: 0.3s;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(0, 245, 255, 0.5);
        }

        .btn-back {
            background: rgba(255, 255, 255, 0.15);
            margin-left: 10px;
        }

        .btn-back:hover {
            background: rgba(255, 255, 255, 0.25);
        }

        @media (max-width: 480px) {
            .card {
                padding: 25px;
            }
        }

        .error {
            color: #ff6b6b;
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="card">
        <c:choose>
            <c:when test="${not empty profile}">
                <!-- Success Message -->
                <div class="success-msg">✅ Profile created successfully!</div>

                <!-- Profile Picture -->
                <c:choose>
                    <c:when test="${not empty profile.profilePic}">
                        <img src="${pageContext.request.contextPath}/${profile.profilePic}" class="profile-img" alt="Profile">
                    </c:when>
                    <c:otherwise>
                        <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" class="profile-img" alt="Default">
                    </c:otherwise>
                </c:choose>

                <h2>${profile.fullname}</h2>
                <div class="program">${profile.program}</div>

                <div class="info">
                    <div class="label">Student ID</div>
                    <div class="value">${profile.studentid}</div>
                </div>

                <div class="info">
                    <div class="label">Email</div>
                    <div class="value">${profile.email}</div>
                </div>

                <div class="info">
                    <div class="label">Hobbies</div>
                    <div class="value">${profile.hobbies}</div>
                </div>

                <div class="info">
                    <div class="label">Professional Bio</div>
                    <div class="value bio-text">${profile.bio}</div>
                </div>

                <div>
                    <a href="ProfileController" class="btn btn-back">← Back to List</a>
                    <a href="ExportPDFServlet?id=${profile.id}" class="btn" style="background: linear-gradient(135deg, #ff6b6b, #ee5a24);">📄 Export to PDF</a>
                </div>
            </c:when>
            <c:otherwise>
                <p class="error">⚠️ Profile not found.</p>
                <a href="ProfileController" class="btn">← Back to List</a>
            </c:otherwise>
        </c:choose>
    </div>
</body>
</html>