package dao;

import model.Profile;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProfileDAO {

    // Database credentials – change these to match your setup
    private static final String URL = "jdbc:mysql://localhost:3306/student_db";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // leave blank if no password

    // Load the MySQL JDBC driver (runs once when class is loaded)
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Get a connection to the database
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // 1. Save a new profile to the database
    public int save(Profile profile) throws SQLException {
        String sql = "INSERT INTO profiles (fullname, studentid, program, email, hobbies, bio, profile_pic) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            ps.setString(1, profile.getFullname());
            ps.setString(2, profile.getStudentid());
            ps.setString(3, profile.getProgram());
            ps.setString(4, profile.getEmail());
            ps.setString(5, profile.getHobbies());
            ps.setString(6, profile.getBio());
            ps.setString(7, profile.getProfilePic());

            int affected = ps.executeUpdate();
            if (affected == 0) {
                throw new SQLException("Insert failed");
            }

            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("No ID obtained");
                }
            }
        }
    }

    // 2. Get all profiles
    public List<Profile> getAllProfiles() throws SQLException {
        List<Profile> list = new ArrayList<>();
        String sql = "SELECT * FROM profiles ORDER BY id DESC";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Profile p = new Profile();
                p.setId(rs.getInt("id"));
                p.setFullname(rs.getString("fullname"));
                p.setStudentid(rs.getString("studentid"));
                p.setProgram(rs.getString("program"));
                p.setEmail(rs.getString("email"));
                p.setHobbies(rs.getString("hobbies"));
                p.setBio(rs.getString("bio"));
                p.setProfilePic(rs.getString("profile_pic"));
                list.add(p);
            }
        }
        return list;
    }

    // 3. Get a single profile by ID
    public Profile getProfileById(int id) throws SQLException {
        String sql = "SELECT * FROM profiles WHERE id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Profile p = new Profile();
                    p.setId(rs.getInt("id"));
                    p.setFullname(rs.getString("fullname"));
                    p.setStudentid(rs.getString("studentid"));
                    p.setProgram(rs.getString("program"));
                    p.setEmail(rs.getString("email"));
                    p.setHobbies(rs.getString("hobbies"));
                    p.setBio(rs.getString("bio"));
                    p.setProfilePic(rs.getString("profile_pic"));
                    return p;
                } else {
                    return null;
                }
            }
        }
    }
}