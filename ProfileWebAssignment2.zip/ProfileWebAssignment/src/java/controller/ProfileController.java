/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.ProfileDAO;
import model.Profile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet(name = "ProfileController", urlPatterns = {"/ProfileController"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,   // 2MB
    maxFileSize = 1024 * 1024 * 10,        // 10MB
    maxRequestSize = 1024 * 1024 * 50      // 50MB
)
public class ProfileController extends HttpServlet {

    private ProfileDAO profileDAO = new ProfileDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Get form fields
        String fullname = request.getParameter("fullname");
        String studentid = request.getParameter("studentid");
        String program = request.getParameter("program");
        String email = request.getParameter("email");
        String hobbies = request.getParameter("hobbies");
        String bio = request.getParameter("bio");

        // 2. Validation
        if (fullname == null || fullname.isEmpty() ||
            studentid == null || studentid.isEmpty() ||
            program == null || program.isEmpty() ||
            email == null || email.isEmpty() ||
            hobbies == null || hobbies.isEmpty() ||
            bio == null || bio.isEmpty()) {

            response.getWriter().println("All fields are required!");
            return;
        }

        if (!email.contains("@") || !email.contains(".")) {
            response.getWriter().println("Invalid Email Format!");
            return;
        }

        // 3. Handle profile picture upload
        Part filePart = request.getPart("profilePic");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";

        // Create uploads directory if it doesn't exist
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        String filePath = null;
        if (fileName != null && !fileName.isEmpty()) {
            // Generate unique filename to avoid collisions
            String uniqueFileName = System.currentTimeMillis() + "_" + fileName;
            filePath = "uploads" + File.separator + uniqueFileName;
            String fullFilePath = uploadPath + File.separator + uniqueFileName;
            filePart.write(fullFilePath);
        }

        // 4. Populate Profile bean
        Profile profile = new Profile();
        profile.setFullname(fullname);
        profile.setStudentid(studentid);
        profile.setProgram(program);
        profile.setEmail(email);
        profile.setHobbies(hobbies);
        profile.setBio(bio);
        profile.setProfilePic(filePath); // can be null if no file uploaded

        // 5. Save to database
        try {
            profileDAO.save(profile);
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Database error: " + e.getMessage());
            return;
        }

        // 6. Redirect to view-all.jsp to see all profiles
        response.sendRedirect("ProfileController");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("view".equals(action)) {
            // View single profile
            String idParam = request.getParameter("id");
            if (idParam != null) {
                try {
                    int id = Integer.parseInt(idParam);
                    Profile p = profileDAO.getProfileById(id);
                    request.setAttribute("profile", p);
                    request.getRequestDispatcher("profile.jsp").forward(request, response);
                    return;
                } catch (NumberFormatException | SQLException e) {
                    e.printStackTrace();
                }
            }
            response.sendRedirect("ProfileController");
        } else {
            // Default: show all profiles
            try {
                List<Profile> list = profileDAO.getAllProfiles();
                request.setAttribute("profileList", list);
                request.getRequestDispatcher("view-all.jsp").forward(request, response);
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        }
    }
}