package controller;

import dao.ProfileDAO;
import model.Profile;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.IOException;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ExportPDFServlet", urlPatterns = {"/ExportPDFServlet"})
public class ExportPDFServlet extends HttpServlet {

    private ProfileDAO profileDAO = new ProfileDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("id");
        if (idParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing profile ID");
            return;
        }

        try {
            int id = Integer.parseInt(idParam);
            Profile profile = profileDAO.getProfileById(id);

            if (profile == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Profile not found");
                return;
            }

            // Set response headers for PDF download
            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=Resume_" + profile.getFullname() + ".pdf");

            // Create PDF document
            Document document = new Document();
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            // Add content
            // Title
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 24, Font.BOLD, BaseColor.BLUE);
            Paragraph title = new Paragraph("Professional Resume", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph(" ")); // empty line

            // Separator line
            Paragraph line = new Paragraph("___________________________________________________");
            line.setAlignment(Element.ALIGN_CENTER);
            document.add(line);
            document.add(new Paragraph(" "));

            // Profile picture path (just display text if uploaded)
            if (profile.getProfilePic() != null) {
                Paragraph picInfo = new Paragraph("✓ Profile Photo: Uploaded");
                picInfo.setFont(new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY));
                document.add(picInfo);
                document.add(new Paragraph(" "));
            }

            // Use a table for better layout
            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.setSpacingAfter(10);

            // Table headers
            Font boldFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLUE);
            Font normalFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);

            addTableCell(table, "Full Name:", boldFont);
            addTableCell(table, profile.getFullname(), normalFont);

            addTableCell(table, "Student ID:", boldFont);
            addTableCell(table, profile.getStudentid(), normalFont);

            addTableCell(table, "Program:", boldFont);
            addTableCell(table, profile.getProgram(), normalFont);

            addTableCell(table, "Email:", boldFont);
            addTableCell(table, profile.getEmail(), normalFont);

            addTableCell(table, "Hobbies:", boldFont);
            addTableCell(table, profile.getHobbies(), normalFont);

            document.add(table);

            // Bio section
            document.add(new Paragraph("Professional Bio", boldFont));
            document.add(new Paragraph(" "));
            Paragraph bioPara = new Paragraph(profile.getBio());
            bioPara.setFont(normalFont);
            bioPara.setAlignment(Element.ALIGN_JUSTIFIED);
            document.add(bioPara);

            // Footer
            document.add(new Paragraph(" "));
            Paragraph footer = new Paragraph("Generated on: " + new java.util.Date());
            footer.setFont(new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY));
            footer.setAlignment(Element.ALIGN_RIGHT);
            document.add(footer);

            document.close();

        } catch (NumberFormatException | SQLException | DocumentException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating PDF");
        }
    }

    // Helper method to add a table cell
    private void addTableCell(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setPadding(8);
        cell.setBorderColor(BaseColor.LIGHT_GRAY);
        cell.setBorderWidth(0.5f);
        if (font.getStyle() == Font.BOLD) {
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
        }
        table.addCell(cell);
    }
}